const rowsData = ['Trending','POWER HEROES','Jackwoord','Ninja Tichnic','Element Power','New Releases','Horror Side','Guaredes Of Diminsions','Explore Great Adventure','Worries','Wonder Worlds','Police Action'];
const rowsContainer = document.getElementById('rows');
rowsData.forEach(row => {
  const rowDiv = document.createElement('div');
  rowDiv.className = 'row';
  rowDiv.innerHTML = `<h3>${row}</h3><div class='scroller'></div>`;
  for(let i=1;i<=6;i++){
    const card = document.createElement('div');
    card.className='card';
    card.innerHTML=`<img src='https://via.placeholder.com/160x240.png?text=${row}+${i}'/><div class='overlay'><div class='hover-actions'><span class='small-icon'>▶</span><span class='small-icon'>＋</span><span class='small-icon'>ℹ</span></div></div>`;
    rowDiv.querySelector('.scroller').appendChild(card);
  }
  rowsContainer.appendChild(rowDiv);
});
